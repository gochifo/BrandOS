-- Updater MADE BY GOCHIPC
package.path = package.path .. ";/BOS/?.lua"
local gub = require("gub")
local vissable = true
local function drawtop()
  term.clear()
  topBar()
  topText("Updater", 5)
  clearText()
  shell.run("pastebin run gEWNEi61")
  topButton(" X ", 1, "false")
end

drawtop()
while true do
  local event, button, x, y = os.pullEvent()
  if event == "term_resize" then
    drawtop()
    drawindow()
  elseif event == "mouse_click" then
    if y == 1 and x >= 1 and x <= 3 then
      topButton(" X ", 1, "true")
      sleep(0.1)
      return
    end
  end
end